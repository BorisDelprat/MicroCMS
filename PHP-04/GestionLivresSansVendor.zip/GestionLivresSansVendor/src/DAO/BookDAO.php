<?php

	namespace GestionLivres\DAO;

	use GestionLivres\Domain\Book;

	class BookDAO extends DAO
	{

		/**
		 * Find All Books
		 * @return array
		 */
		public function findAll() {

			$sql = "select * from book order by book_id desc";
			$result = $this->getDb()->fetchAll($sql);

			// Convert query result to an array of domain objects
			$books = array();
			foreach ($result as $row) {
				$bookId = $row['book_id'];
				$books[$bookId] = $this->buildDomainObject($row);
			}
			return $books;
		}

		/**
		 * Builder DAO
		 * @param $row
		 * @return Book
		 */
		protected function buildDomainObject($row) {

			$book = new Book();
			$book->setId($row['book_id']);
			$book->setTitle($row['book_title']);
			$book->setIsbn($row['book_isbn']);
			$book->setSummary($row['book_summary']);
			$book->setAuthId($row['auth_id']);

			return $book;
		}

		/**
		 * find Book
		 * @param $id
		 * @return Book
		 * @throws \Exception
		 */
		public function find($id) {

			$sql = "select * from book where book_id=?";
			$row = $this->getDb()->fetchAssoc($sql, array($id));

			if ($row){
				return $this->buildDomainObject($row);
			}
			else{
				throw new \Exception("No book matching id " . $id);
			}
		}

	}