<?php

	namespace GestionLivres\DAO;

	use GestionLivres\Domain\Author;

	class AuthorDAO extends DAO
	{
		private $bookDAO;

		/**Set Book DAO
		 * @param BookDAO $bookDAO
		 */
		public function setBookDAO(BookDAO $bookDAO) {
			$this->bookDAO = $bookDAO;
		}

		/**Builder DAO
		 * @param $row
		 * @return Author
		 */
		protected function buildDomainObject($row) {

			$author = new Author();
			$author->setId($row['auth_id']);
			$author->setAuthFirstName($row['auth_first_name']);
			$author->setAuthLastName($row['auth_last_name']);

			if (array_key_exists('book_id', $row)) {

				// Find and set the associated article
				$bookId = $row['book_id'];
				$book = $this->bookDAO->find($bookId);
				$author->setBook($book);
			}
			return $author;
		}

		/**
		 * Find Author
		 * @param $id
		 * @return Author
		 * @throws \Exception
		 */
		public function find($id) {

			$sql = "select * from author where auth_id=?";
			$row = $this->getDb()->fetchAssoc($sql, array($id));

			if ($row){
				return $this->buildDomainObject($row);
			}
			else{
				throw new \Exception("No author matching id " . $id);
			}
		}
	}