<?php


	namespace GestionLivres\Domain;


	class Book
	{
		/***
		 * @var
		 */
		private $book_id;
		private $book_title;
		private $book_isbn;
		private $book_summary;
		private $auth_id;

		private $author;

		/**
		 * Description Get Id
		 * @return mixed
		 */
		public function getId() {
			return $this->book_id;
		}

		/**
		 * Description Set Id
		 * @param $book_id
		 */
		public function setId($book_id) {
			$this->book_id = $book_id;
		}

		/**
		 * Description Get Title
		 * @return mixed
		 */
		public function getTitle() {
			return $this->book_title;
		}

		/**
		 * Description Set Title
		 * @param $book_title
		 */
		public function setTitle($book_title) {
			$this->book_title = $book_title;
		}

		/**
		 * Description Get Isbn
		 * @return mixed
		 */
		public function getIsbn() {
			return $this->book_isbn;
		}

		/**
		 * Description Set Isbn
		 * @param $book_isbn
		 */
		public function setIsbn($book_isbn) {
			$this->book_isbn = $book_isbn;
		}

		/**
		 * Description Get Summary
		 * @return mixed
		 */
		public function getSummary() {
			return $this->book_summary;
		}

		/**
		 * Description set Summary
		 * @param $book_summary
		 */
		public function setSummary($book_summary) {
			$this->book_summary = $book_summary;
		}

		/**
		 * Description Get AuthId
		 * @return mixed
		 */
		public function getAuthId() {
			return $this->auth_id;
		}

		/**
		 * Description Set AuthId
		 * @param $auth_id
		 */
		public function setAuthId($auth_id) {
			$this->auth_id = $auth_id;
		}

		/**
		 * Description Get Author (objet)
		 * @return mixed
		 */
		public function getAuthor() {
			return $this->author;
		}

		/**
		 * Description Set Author (objet)
		 * @param Author $author
		 */
		public function setAuthor(Author $author) {
			$this->author = $author;
		}

	}