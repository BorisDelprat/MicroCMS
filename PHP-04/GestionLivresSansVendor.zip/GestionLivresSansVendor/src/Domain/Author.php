<?php

	namespace GestionLivres\Domain;


	class Author
	{
		/**
		 * @var
		 */
		private $auth_id;
		private $auth_first_name;
		private $auth_last_name;

		private $book;


		/**
		 * Get Id
		 * @return mixed
		 */
		public function getId() {
			return $this->auth_id;
		}

		/**
		 * Set Id
		 * @param $auth_id
		 */
		public function setId($auth_id) {
			$this->auth_id = $auth_id;
		}

		/**Get Auth first name
		 * @return mixed
		 */
		public function getAuthFirstName() {
			return $this->auth_first_name;
		}

		/**Set Auth first name
		 * @param $auth_first_name
		 */
		public function setAuthFirstName($auth_first_name) {
			$this->auth_first_name = $auth_first_name;
		}

		/**
		 * Get Auth last name
		 * @return mixed
		 */
		public function getAuthLastName() {
			return $this->auth_last_name;
		}

		/**
		 * Get Auth last name
		 * @param $auth_last_name
		 */
		public function setAuthLastName($auth_last_name) {
			$this->auth_last_name = $auth_last_name;
		}

		/**
		 * get Book
		 * @return mixed
		 */
		public function getBook() {
			return $this->book;
		}

		/**
		 * set Book
		 * @param Book $book
		 */
		public function setBook(Book $book) {
			$this->book = $book;
		}
	}